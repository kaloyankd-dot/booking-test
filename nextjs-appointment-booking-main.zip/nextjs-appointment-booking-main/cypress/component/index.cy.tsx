/// <reference types="cypress" />

describe('My first test', () => {
  it('Does nothing', () => {
    expect(true).to.equal(true);
  });
});
