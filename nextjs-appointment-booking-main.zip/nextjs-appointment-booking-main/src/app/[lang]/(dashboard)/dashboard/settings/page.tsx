export default function SettingsDashboardPage() {
  return <div>SettingsDashboardPage</div>;
}
