export type Collections = 'appointments' | 'sellers' | 'opening-time';
